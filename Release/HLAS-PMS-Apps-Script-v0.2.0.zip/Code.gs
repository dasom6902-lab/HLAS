/**
 * 스프레드시트를 열 때 HLAS-PMS 사용자 메뉴를 생성한다.
 *
 * 메뉴 항목에는 반드시 전역 함수 이름을 문자열로 연결해야 한다.
 * Apps Script는 이 이름을 사용하여 사용자가 선택한 기능을 실행한다.
 */
function onOpen() {
  const ui = SpreadsheetApp.getUi();

  ui
    .createMenu('HLAS-PMS')
    .addItem('PMS 초기화', 'initializePMS')
    .addSeparator()
    .addItem('프로젝트 생성', 'createProject')
    .addItem('TASK 생성', 'createTask')
    .addSeparator()
    .addItem('CHANGELOG 보기', 'showChangeLog')
    .addItem('환경설정', 'openSettings')
    .addSeparator()
    .addItem('도움말', 'showHelp')
    .addToUi();
}

/**
 * 프로젝트 생성 메뉴의 연결 함수.
 * 실제 프로젝트 등록 화면은 후속 TASK에서 구현한다.
 */
function createProject() {
  showComingSoon_('프로젝트 생성');
}

/**
 * TASK 생성 메뉴의 연결 함수.
 * 실제 TASK 등록 화면과 자동 번호 발급은 후속 TASK에서 구현한다.
 */
function createTask() {
  showComingSoon_('TASK 생성');
}

/**
 * 변경 이력 시트를 열어 사용자가 바로 확인할 수 있도록 한다.
 * 초기화 전이라 대상 시트가 없으면 준비중 안내를 표시한다.
 */
function showChangeLog() {
  activatePmsSheet_('09_CHANGELOG', 'CHANGELOG 보기');
}

/**
 * 환경설정 시트를 연다.
 * 초기화 전이라 대상 시트가 없으면 준비중 안내를 표시한다.
 */
function openSettings() {
  activatePmsSheet_('99_SETTING', '환경설정');
}

/**
 * 현재 메뉴에서 사용할 수 있는 기능을 간단히 안내한다.
 */
function showHelp() {
  SpreadsheetApp.getUi().alert(
    'HLAS-PMS 도움말',
    [
      'PMS 초기화: 핵심 관리 시트와 기본 설정을 생성합니다.',
      '프로젝트 생성: 준비중입니다.',
      'TASK 생성: 준비중입니다.',
      'CHANGELOG 보기: 변경 이력 시트로 이동합니다.',
      '환경설정: 시스템 설정 시트로 이동합니다.',
    ].join('\n'),
    SpreadsheetApp.getUi().ButtonSet.OK
  );
}

/**
 * 아직 구현되지 않은 메뉴 기능에 공통 안내창을 표시한다.
 *
 * @param {string} featureName 선택한 기능명
 */
function showComingSoon_(featureName) {
  SpreadsheetApp.getUi().alert(
    featureName,
    '준비중입니다.',
    SpreadsheetApp.getUi().ButtonSet.OK
  );
}

/**
 * 지정한 PMS 시트를 활성화한다.
 *
 * @param {string} sheetName 이동할 시트명
 * @param {string} featureName 사용자에게 표시할 기능명
 */
function activatePmsSheet_(sheetName, featureName) {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = spreadsheet.getSheetByName(sheetName);

  if (!sheet) {
    showComingSoon_(featureName);
    return;
  }

  spreadsheet.setActiveSheet(sheet);
}

/**
 * Creates and formats the core HLAS-PMS sheets.
 *
 * Safe to run more than once:
 * - Existing sheets are retained.
 * - Only row 1 (the schema header) is refreshed.
 * - Existing data below row 1 is not deleted.
 */
function initializePMS() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  if (!spreadsheet) {
    throw new Error('연결된 Google 스프레드시트에서 실행해야 합니다.');
  }

  const lock = LockService.getDocumentLock();
  lock.waitLock(30000);

  const startedAt = new Date();
  const createdSheets = [];
  const updatedSheets = [];

  try {
    PMS_CONFIG.sheets.forEach(function (definition) {
      let sheet = spreadsheet.getSheetByName(definition.name);

      if (!sheet) {
        sheet = spreadsheet.insertSheet(definition.name);
        createdSheets.push(definition.name);
      } else {
        updatedSheets.push(definition.name);
      }

      ensureSheetSize_(sheet, definition.headers.length);
      writeAndFormatHeader_(sheet, definition);
    });

    seedSettings_(spreadsheet);
    seedHome_(spreadsheet);

    const summary = [
      'PMS 초기화 완료',
      '신규 시트: ' + (createdSheets.length ? createdSheets.join(', ') : '없음'),
      '기존 시트 갱신: ' + (updatedSheets.length ? updatedSheets.join(', ') : '없음'),
    ].join(' / ');

    appendChangeLog_(spreadsheet, summary, startedAt);
    spreadsheet.setActiveSheet(spreadsheet.getSheetByName('00_HOME'));
    SpreadsheetApp.flush();
    spreadsheet.toast(summary, PMS_CONFIG.appName, 8);

    return {
      success: true,
      createdSheets: createdSheets,
      updatedSheets: updatedSheets,
      message: summary,
    };
  } catch (error) {
    try {
      appendChangeLog_(
        spreadsheet,
        'PMS 초기화 실패: ' + (error && error.message ? error.message : String(error)),
        startedAt,
        '실패'
      );
    } catch (loggingError) {
      console.error(loggingError);
    }
    throw error;
  } finally {
    lock.releaseLock();
  }
}

function ensureSheetSize_(sheet, requiredColumns) {
  const missingColumns = requiredColumns - sheet.getMaxColumns();
  if (missingColumns > 0) {
    sheet.insertColumnsAfter(sheet.getMaxColumns(), missingColumns);
  }
}

function writeAndFormatHeader_(sheet, definition) {
  const columnCount = definition.headers.length;
  const headerRange = sheet.getRange(1, 1, 1, columnCount);

  headerRange
    .setValues([definition.headers])
    .setBackground(PMS_CONFIG.headerBackground)
    .setFontColor(PMS_CONFIG.headerFontColor)
    .setFontWeight('bold')
    .setFontSize(PMS_CONFIG.headerFontSize)
    .setHorizontalAlignment('center')
    .setVerticalAlignment('middle')
    .setWrap(true);

  sheet.setFrozenRows(1);
  sheet.setRowHeight(1, 32);

  (definition.widths || []).forEach(function (width, index) {
    sheet.setColumnWidth(index + 1, width);
  });

  if (!definition.widths || definition.widths.length !== columnCount) {
    sheet.autoResizeColumns(1, columnCount);
  }
}

function seedSettings_(spreadsheet) {
  const sheet = spreadsheet.getSheetByName('99_SETTING');
  if (sheet.getLastRow() > 1) {
    return;
  }

  const now = new Date();
  const rows = [
    ['SYSTEM', 'APP_NAME', PMS_CONFIG.appName, '애플리케이션 이름', 'Y', now],
    ['SYSTEM', 'VERSION', PMS_CONFIG.version, '현재 PMS 버전', 'Y', now],
    ['SYSTEM', 'ENVIRONMENT', 'DEV', 'DEV / TEST / PROD', 'Y', now],
    ['CODE', 'STATUS', 'Draft,Analysis,Design,Approved,Development,Testing,Done,Closed', '표준 상태값', 'Y', now],
    ['CODE', 'PRIORITY', '긴급,높음,보통,낮음', '표준 우선순위', 'Y', now],
  ];

  sheet.getRange(2, 1, rows.length, rows[0].length).setValues(rows);
  sheet.getRange(2, 6, rows.length, 1).setNumberFormat('yyyy-mm-dd hh:mm:ss');
}

function seedHome_(spreadsheet) {
  const sheet = spreadsheet.getSheetByName('00_HOME');
  if (sheet.getLastRow() > 1) {
    return;
  }

  const now = new Date();
  const rows = [
    ['프로젝트', 'HLAS (Hansalim Logistics Automation System)', now],
    ['관리 시스템', PMS_CONFIG.appName, now],
    ['현재 버전', PMS_CONFIG.version, now],
    ['상태', '초기화 완료', now],
  ];

  sheet.getRange(2, 1, rows.length, rows[0].length).setValues(rows);
  sheet.getRange(2, 3, rows.length, 1).setNumberFormat('yyyy-mm-dd hh:mm:ss');
}

function appendChangeLog_(spreadsheet, message, timestamp, result) {
  const sheet = spreadsheet.getSheetByName('09_CHANGELOG');
  if (!sheet) {
    throw new Error('09_CHANGELOG 시트를 찾을 수 없습니다.');
  }

  const now = timestamp || new Date();
  const logId = 'LOG-' + Utilities.formatDate(
    now,
    Session.getScriptTimeZone(),
    'yyyyMMddHHmmss'
  );
  const userEmail = Session.getActiveUser().getEmail() || 'UNKNOWN';

  sheet.appendRow([
    logId,
    PMS_CONFIG.version,
    now,
    'INITIALIZE',
    message,
    'HLAS-PMS',
    userEmail,
    result || '성공',
  ]);

  sheet.getRange(sheet.getLastRow(), 3).setNumberFormat('yyyy-mm-dd hh:mm:ss');
}
