/**
 * HLAS-PMS에서 공통으로 사용하는 상수.
 *
 * 신규 기능은 시트명, 상태값, 로그 유형 등의 공통 문자열을
 * 기능 코드에 직접 작성하지 않고 이 객체를 참조한다.
 */
const HLAS_CONSTANTS = Object.freeze({
  SHEETS: Object.freeze({
    PROJECT: '01_PROJECT',
    EPIC: '02_EPIC',
    FEATURE: '03_FEATURE',
    CHANGELOG: '09_CHANGELOG',
  }),
  STATUS: Object.freeze({
    IN_PROGRESS: '진행중',
    ON_HOLD: '보류',
    COMPLETED: '완료',
    CANCELLED: '취소',
    VALUES: Object.freeze(['진행중', '보류', '완료', '취소']),
  }),
  PRIORITY: Object.freeze({
    URGENT: '긴급',
    HIGH: '높음',
    NORMAL: '보통',
    LOW: '낮음',
    VALUES: Object.freeze(['긴급', '높음', '보통', '낮음']),
  }),
  LOG_TYPE: Object.freeze({
    FEATURE_CREATE: 'FEATURE 생성',
    FEATURE_UPDATE: 'FEATURE 수정',
    FEATURE_DELETE: 'FEATURE 삭제',
  }),
  LOG_RESULT: Object.freeze({
    SUCCESS: '성공',
    FAILURE: '실패',
  }),
  ID: Object.freeze({
    FEATURE_PREFIX: 'FEAT-',
    PAD_LENGTH: 4,
  }),
  FIELD: Object.freeze({
    FEATURE_ID: 'FEATURE_ID',
    EPIC_ID: 'EPIC_ID',
    FEATURE_NAME: 'FEATURE명',
    DESCRIPTION: '설명',
    STATUS: '상태',
    PRIORITY: '우선순위',
    OWNER: '담당자',
    CREATED_AT: '생성일시',
    UPDATED_AT: '수정일시',
  }),
});
