/**
 * 스프레드시트를 열 때 HLAS-PMS 사용자 메뉴를 생성한다.
 *
 * Project, Task 등 업무 영역은 하위 메뉴로 분리하여 기능이 늘어나도
 * 사용자가 필요한 메뉴를 쉽게 찾을 수 있도록 구성한다.
 */
function onOpen() {
  const ui = SpreadsheetApp.getUi();

  const projectMenu = ui
    .createMenu('프로젝트 관리')
    .addItem('프로젝트 생성', 'showProjectCreateDialog');

  ui
    .createMenu('HLAS-PMS')
    .addItem('PMS 초기화', 'initializePMS')
    .addSeparator()
    .addSubMenu(projectMenu)
    .addItem('TASK 생성', 'createTask')
    .addSeparator()
    .addItem('CHANGELOG 보기', 'showChangeLog')
    .addItem('환경설정', 'openSettings')
    .addSeparator()
    .addItem('도움말', 'showHelp')
    .addToUi();
}

/**
 * 프로젝트 생성 HTML 화면을 모달 대화상자로 표시한다.
 */
function showProjectCreateDialog() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();

  if (!spreadsheet.getSheetByName('01_PROJECT')) {
    SpreadsheetApp.getUi().alert(
      '프로젝트 생성',
      '먼저 HLAS-PMS 메뉴에서 PMS 초기화를 실행해 주세요.',
      SpreadsheetApp.getUi().ButtonSet.OK
    );
    return;
  }

  const html = HtmlService
    .createHtmlOutputFromFile('Dialog_Project')
    .setWidth(520)
    .setHeight(540);

  SpreadsheetApp.getUi().showModalDialog(html, '프로젝트 생성');
}

/**
 * TASK 생성 메뉴의 연결 함수.
 * 실제 TASK 등록 화면은 후속 TASK에서 구현한다.
 */
function createTask() {
  showComingSoon_('TASK 생성');
}

/**
 * 변경 이력 시트를 열어 사용자가 바로 확인할 수 있도록 한다.
 */
function showChangeLog() {
  activatePmsSheet_('09_CHANGELOG', 'CHANGELOG 보기');
}

/**
 * 환경설정 시트를 연다.
 */
function openSettings() {
  activatePmsSheet_('99_SETTING', '환경설정');
}

/**
 * 현재 메뉴에서 사용할 수 있는 기능을 안내한다.
 */
function showHelp() {
  SpreadsheetApp.getUi().alert(
    'HLAS-PMS 도움말',
    [
      'PMS 초기화: 핵심 관리 시트와 기본 설정을 생성합니다.',
      '프로젝트 관리 > 프로젝트 생성: 새 프로젝트를 등록합니다.',
      'TASK 생성: 준비중입니다.',
      'CHANGELOG 보기: 변경 이력 시트로 이동합니다.',
      '환경설정: 시스템 설정 시트로 이동합니다.',
    ].join('\n'),
    SpreadsheetApp.getUi().ButtonSet.OK
  );
}

/**
 * 아직 구현되지 않은 메뉴 기능에 공통 안내창을 표시한다.
 *
 * @param {string} featureName 선택한 기능명
 */
function showComingSoon_(featureName) {
  SpreadsheetApp.getUi().alert(
    featureName,
    '준비중입니다.',
    SpreadsheetApp.getUi().ButtonSet.OK
  );
}

/**
 * 지정한 PMS 시트를 활성화한다.
 *
 * @param {string} sheetName 이동할 시트명
 * @param {string} featureName 사용자에게 표시할 기능명
 */
function activatePmsSheet_(sheetName, featureName) {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = spreadsheet.getSheetByName(sheetName);

  if (!sheet) {
    showComingSoon_(featureName);
    return;
  }

  spreadsheet.setActiveSheet(sheet);
}

