/**
 * 모든 HLAS Domain API가 공유하는 표준 응답과 공통 처리를 제공한다.
 */
const CommonAPI = Object.freeze({
  /**
   * 성공 응답을 생성한다.
   */
  success: function (data, meta) {
    return {
      ok: true,
      data: data === undefined ? null : data,
      error: null,
      meta: buildApiMeta_(meta),
    };
  },

  /**
   * 실패 응답을 생성한다.
   */
  fail: function (error, meta) {
    const normalizedError = normalizeApiError_(error);
    return {
      ok: false,
      data: null,
      error: normalizedError,
      meta: buildApiMeta_(meta),
    };
  },

  /**
   * 검증 함수를 실행한다.
   *
   * 검증 함수는 실패 시 CoreError를 발생시켜야 한다.
   */
  validate: function (validator) {
    if (typeof validator !== 'function') {
      throw new ValidationError('검증 함수가 필요합니다.', 'validator');
    }
    validator();
    return true;
  },

  /**
   * 표준 CHANGELOG 행을 기록한다.
   *
   * 신규 Core API는 기존 appendChangeLog_() 대신 이 함수를 사용한다.
   */
  writeLog: function (logData) {
    const data = logData || {};
    const now = data.timestamp instanceof Date ? data.timestamp : new Date();
    const logId = data.logId || createCommonLogId_();
    const actor = data.actor || Session.getActiveUser().getEmail() || 'UNKNOWN';

    const record = {
      LOG_ID: logId,
      버전: data.version || (typeof PMS_CONFIG !== 'undefined' ? PMS_CONFIG.version : ''),
      변경일시: now,
      변경유형: data.changeType || 'SYSTEM',
      변경내용: data.message || '',
      관련ID: data.relatedId || '',
      작업자: actor,
      결과: data.result || '성공',
    };

    SheetRepository.insert('09_CHANGELOG', record);
    return record;
  },

  /**
   * Endpoint의 실행 함수를 표준 응답으로 감싼다.
   */
  execute: function (handler, meta) {
    try {
      if (typeof handler !== 'function') {
        throw new ValidationError('실행 함수가 필요합니다.', 'handler');
      }
      return this.success(handler(), meta);
    } catch (error) {
      return this.fail(error, meta);
    }
  },
});

function buildApiMeta_(meta) {
  const input = meta || {};
  return {
    requestId: input.requestId || createCommonRequestId_(),
    timestamp: new Date().toISOString(),
    version: input.version || (typeof PMS_CONFIG !== 'undefined' ? PMS_CONFIG.version : ''),
  };
}

function normalizeApiError_(error) {
  if (error instanceof CoreError) {
    return error.toObject();
  }

  return {
    code: 'INTERNAL_ERROR',
    message: error && error.message ? error.message : '시스템 오류가 발생했습니다.',
    field: null,
    details: null,
  };
}

function createCommonRequestId_() {
  return 'REQ-' + Utilities.getUuid();
}

function createCommonLogId_() {
  return 'LOG-' + Utilities.getUuid();
}

