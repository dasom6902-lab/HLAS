# TASK-0004 1단계 — EPIC 기능 구현 보고

## 상태

구현 완료 / Google Apps Script 실행 테스트 대기

## ① 추가된 파일

- `EpicService.gs`
- `Dialog_Epic.html`
- `Dialog_EpicList.html`
- `TASK-0004_STEP1_REPORT.md`

## ② 수정된 파일

- `UI.gs`
- `Config.gs`
- `README.md`

## ③ 전체 파일 구조

```text
AppsScript/
├─ Code.gs
├─ Config.gs
├─ UI.gs
├─ ProjectService.gs
├─ EpicService.gs
├─ Dialog_Project.html
├─ Dialog_Epic.html
├─ Dialog_EpicList.html
└─ appsscript.json
```

## ④ 구현한 기능 목록

- `HLAS-PMS > EPIC 관리 > EPIC 생성`
- `HLAS-PMS > EPIC 관리 > EPIC 목록 조회`
- 프로젝트 선택 목록 조회
- PROJECT_ID 존재 여부 검증
- EPIC명 필수 검증
- 임시 EPIC_ID 자동 생성 (`EPIC-0001`)
- 문서 잠금을 이용한 ID 중복 방지
- `02_EPIC` 저장
- 상태 기본값 `진행중`
- 생성일시와 수정일시 자동 입력
- `09_CHANGELOG` 자동 기록
- 프로젝트명이 포함된 EPIC 목록 표시

## ⑤ 테스트 결과

### 정적 검토

- 메뉴 연결 함수명 확인: 통과
- 02_EPIC 헤더 순서와 저장 배열 순서 확인: 통과
- PROJECT_ID 연계 검증 확인: 통과
- EPIC_ID 정규식 및 순차 증가 로직 확인: 통과
- HTML 클라이언트/서버 함수 연결 확인: 통과
- CHANGELOG 호출 인수 확인: 통과

### 실행 테스트

Google Apps Script에 반영 후 사용자 환경에서 실행 확인이 필요하다.

## ⑥ 공통모듈 후보 코드

### IdGenerator.gs 후보

- `generateNextEpicId_()`
- `ProjectService.gs`의 `generateNextProjectId_()`
- 문서 잠금 적용 방식

### Validation.gs 후보

- `createEpicRecord()`의 필수값 검증
- `epicProjectExists_()`
- `parseEpicDate_()`
- `ProjectService.gs`의 프로젝트 검증과 날짜 변환

### LogService.gs 후보

- `appendChangeLog_()`
- 변경유형, 관련 ID, 결과 인수 표준화

### DialogManager.gs 후보

- `showEpicCreateDialog()`
- `showEpicListDialog()`
- `showProjectCreateDialog()`
- 시트 존재 확인, HTML 생성, 크기 지정, 모달 표시

