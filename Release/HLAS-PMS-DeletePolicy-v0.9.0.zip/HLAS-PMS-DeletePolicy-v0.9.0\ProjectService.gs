/**
 * HTML 대화상자에서 전달받은 프로젝트 정보를 검증하고 저장한다.
 *
 * @param {Object} formData 프로젝트 입력값
 * @return {Object} 클라이언트에 전달할 처리 결과
 */
function createProjectRecord(formData) {
  const data = formData || {};
  const projectName = String(data.projectName || '').trim();

  // 프로젝트명은 유일한 필수 입력값이다.
  if (!projectName) {
    throw new Error('프로젝트명을 입력해 주세요.');
  }

  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const projectSheet = spreadsheet.getSheetByName('01_PROJECT');

  if (!projectSheet) {
    throw new Error('01_PROJECT 시트가 없습니다. PMS 초기화를 먼저 실행해 주세요.');
  }

  // 동시에 여러 사용자가 저장하더라도 같은 ID가 발급되지 않도록
  // 문서 잠금 안에서 ID 생성과 행 저장을 한 번에 처리한다.
  const lock = LockService.getDocumentLock();
  lock.waitLock(30000);

  try {
    const projectId = generateNextProjectId_(projectSheet);
    const now = new Date();
    const row = [
      projectId,
      projectName,
      String(data.description || '').trim(),
      '진행중',
      '',
      String(data.owner || '').trim(),
      parseProjectDate_(data.startDate),
      parseProjectDate_(data.plannedEndDate),
      now,
      now,
    ];

    projectSheet.appendRow(row);

    const savedRow = projectSheet.getLastRow();
    projectSheet.getRange(savedRow, 7, 1, 2).setNumberFormat('yyyy-mm-dd');
    projectSheet.getRange(savedRow, 9, 1, 2).setNumberFormat('yyyy-mm-dd hh:mm:ss');

    appendChangeLog_(
      spreadsheet,
      '프로젝트 생성: ' + projectName,
      now,
      '성공',
      '프로젝트 생성',
      projectId
    );

    SpreadsheetApp.flush();

    return {
      success: true,
      projectId: projectId,
      message: '프로젝트가 생성되었습니다.',
    };
  } finally {
    lock.releaseLock();
  }
}

/**
 * PROJECT를 삭제한다. 하위 EPIC이 있으면 삭제하지 않는다.
 *
 * @param {string} id 삭제할 PROJECT_ID
 * @return {Object} Core API 표준 응답
 */
function deleteProject(id) {
  return CommonAPI.execute(function () {
    Validation.required(id, HLAS_CONSTANTS.PROJECT_FIELD.PROJECT_ID);
    const normalizedId = String(id).trim();
    const current = SheetRepository.findById(
      HLAS_CONSTANTS.SHEETS.PROJECT,
      normalizedId
    );

    if (!current) {
      throw new NotFoundError(
        '삭제할 PROJECT를 찾을 수 없습니다: ' + normalizedId,
        HLAS_CONSTANTS.PROJECT_FIELD.PROJECT_ID,
        { id: normalizedId }
      );
    }

    assertDeleteAllowed_(
      canDeleteProject(normalizedId),
      HLAS_CONSTANTS.PROJECT_FIELD.PROJECT_ID,
      normalizedId
    );
    SheetRepository.delete(HLAS_CONSTANTS.SHEETS.PROJECT, normalizedId);

    CommonAPI.writeLog({
      changeType: HLAS_CONSTANTS.LOG_TYPE.PROJECT_DELETE,
      message:
        'PROJECT 삭제: ' +
        current[HLAS_CONSTANTS.PROJECT_FIELD.PROJECT_NAME],
      relatedId: normalizedId,
      result: HLAS_CONSTANTS.LOG_RESULT.SUCCESS,
    });

    return { projectId: normalizedId, deleted: true };
  }, { operation: 'deleteProject' });
}

/**
 * 01_PROJECT 시트의 기존 ID 중 가장 큰 번호 다음 값을 발급한다.
 *
 * 예: PRJ-0001, PRJ-0002
 *
 * @param {GoogleAppsScript.Spreadsheet.Sheet} sheet 프로젝트 시트
 * @return {string} 새 PROJECT_ID
 */
function generateNextProjectId_(sheet) {
  const lastRow = sheet.getLastRow();
  let maxNumber = 0;

  if (lastRow > 1) {
    const ids = sheet.getRange(2, 1, lastRow - 1, 1).getDisplayValues();

    ids.forEach(function (row) {
      const match = String(row[0] || '').trim().match(/^PRJ-(\d{4,})$/);
      if (match) {
        maxNumber = Math.max(maxNumber, Number(match[1]));
      }
    });
  }

  const nextNumber = maxNumber + 1;
  return 'PRJ-' + String(nextNumber).padStart(4, '0');
}

/**
 * HTML date 입력값(yyyy-mm-dd)을 스프레드시트 날짜로 변환한다.
 * 값이 없으면 빈 문자열을 반환한다.
 *
 * @param {string} value 날짜 입력값
 * @return {Date|string} 변환된 날짜 또는 빈 값
 */
function parseProjectDate_(value) {
  const text = String(value || '').trim();
  if (!text) {
    return '';
  }

  const parts = text.split('-').map(Number);
  if (
    parts.length !== 3 ||
    !parts[0] ||
    !parts[1] ||
    !parts[2]
  ) {
    throw new Error('날짜 형식이 올바르지 않습니다.');
  }

  return new Date(parts[0], parts[1] - 1, parts[2]);
}
