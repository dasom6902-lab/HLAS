/**
 * Adds an HLAS-PMS menu whenever the spreadsheet opens.
 */
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('HLAS-PMS')
    .addItem('PMS 초기화', 'initializePMS')
    .addToUi();
}

/**
 * Creates and formats the core HLAS-PMS sheets.
 *
 * Safe to run more than once:
 * - Existing sheets are retained.
 * - Only row 1 (the schema header) is refreshed.
 * - Existing data below row 1 is not deleted.
 */
function initializePMS() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  if (!spreadsheet) {
    throw new Error('연결된 Google 스프레드시트에서 실행해야 합니다.');
  }

  const lock = LockService.getDocumentLock();
  lock.waitLock(30000);

  const startedAt = new Date();
  const createdSheets = [];
  const updatedSheets = [];

  try {
    PMS_CONFIG.sheets.forEach(function (definition) {
      let sheet = spreadsheet.getSheetByName(definition.name);

      if (!sheet) {
        sheet = spreadsheet.insertSheet(definition.name);
        createdSheets.push(definition.name);
      } else {
        updatedSheets.push(definition.name);
      }

      ensureSheetSize_(sheet, definition.headers.length);
      writeAndFormatHeader_(sheet, definition);
    });

    seedSettings_(spreadsheet);
    seedHome_(spreadsheet);

    const summary = [
      'PMS 초기화 완료',
      '신규 시트: ' + (createdSheets.length ? createdSheets.join(', ') : '없음'),
      '기존 시트 갱신: ' + (updatedSheets.length ? updatedSheets.join(', ') : '없음'),
    ].join(' / ');

    appendChangeLog_(spreadsheet, summary, startedAt);
    spreadsheet.setActiveSheet(spreadsheet.getSheetByName('00_HOME'));
    SpreadsheetApp.flush();
    spreadsheet.toast(summary, PMS_CONFIG.appName, 8);

    return {
      success: true,
      createdSheets: createdSheets,
      updatedSheets: updatedSheets,
      message: summary,
    };
  } catch (error) {
    try {
      appendChangeLog_(
        spreadsheet,
        'PMS 초기화 실패: ' + (error && error.message ? error.message : String(error)),
        startedAt,
        '실패'
      );
    } catch (loggingError) {
      console.error(loggingError);
    }
    throw error;
  } finally {
    lock.releaseLock();
  }
}

function ensureSheetSize_(sheet, requiredColumns) {
  const missingColumns = requiredColumns - sheet.getMaxColumns();
  if (missingColumns > 0) {
    sheet.insertColumnsAfter(sheet.getMaxColumns(), missingColumns);
  }
}

function writeAndFormatHeader_(sheet, definition) {
  const columnCount = definition.headers.length;
  const headerRange = sheet.getRange(1, 1, 1, columnCount);

  headerRange
    .setValues([definition.headers])
    .setBackground(PMS_CONFIG.headerBackground)
    .setFontColor(PMS_CONFIG.headerFontColor)
    .setFontWeight('bold')
    .setFontSize(PMS_CONFIG.headerFontSize)
    .setHorizontalAlignment('center')
    .setVerticalAlignment('middle')
    .setWrap(true);

  sheet.setFrozenRows(1);
  sheet.setRowHeight(1, 32);

  (definition.widths || []).forEach(function (width, index) {
    sheet.setColumnWidth(index + 1, width);
  });

  if (!definition.widths || definition.widths.length !== columnCount) {
    sheet.autoResizeColumns(1, columnCount);
  }
}

function seedSettings_(spreadsheet) {
  const sheet = spreadsheet.getSheetByName('99_SETTING');
  if (sheet.getLastRow() > 1) {
    return;
  }

  const now = new Date();
  const rows = [
    ['SYSTEM', 'APP_NAME', PMS_CONFIG.appName, '애플리케이션 이름', 'Y', now],
    ['SYSTEM', 'VERSION', PMS_CONFIG.version, '현재 PMS 버전', 'Y', now],
    ['SYSTEM', 'ENVIRONMENT', 'DEV', 'DEV / TEST / PROD', 'Y', now],
    ['CODE', 'STATUS', 'Draft,Analysis,Design,Approved,Development,Testing,Done,Closed', '표준 상태값', 'Y', now],
    ['CODE', 'PRIORITY', '긴급,높음,보통,낮음', '표준 우선순위', 'Y', now],
  ];

  sheet.getRange(2, 1, rows.length, rows[0].length).setValues(rows);
  sheet.getRange(2, 6, rows.length, 1).setNumberFormat('yyyy-mm-dd hh:mm:ss');
}

function seedHome_(spreadsheet) {
  const sheet = spreadsheet.getSheetByName('00_HOME');
  if (sheet.getLastRow() > 1) {
    return;
  }

  const now = new Date();
  const rows = [
    ['프로젝트', 'HLAS (Hansalim Logistics Automation System)', now],
    ['관리 시스템', PMS_CONFIG.appName, now],
    ['현재 버전', PMS_CONFIG.version, now],
    ['상태', '초기화 완료', now],
  ];

  sheet.getRange(2, 1, rows.length, rows[0].length).setValues(rows);
  sheet.getRange(2, 3, rows.length, 1).setNumberFormat('yyyy-mm-dd hh:mm:ss');
}

function appendChangeLog_(spreadsheet, message, timestamp, result) {
  const sheet = spreadsheet.getSheetByName('09_CHANGELOG');
  if (!sheet) {
    throw new Error('09_CHANGELOG 시트를 찾을 수 없습니다.');
  }

  const now = timestamp || new Date();
  const logId = 'LOG-' + Utilities.formatDate(
    now,
    Session.getScriptTimeZone(),
    'yyyyMMddHHmmss'
  );
  const userEmail = Session.getActiveUser().getEmail() || 'UNKNOWN';

  sheet.appendRow([
    logId,
    PMS_CONFIG.version,
    now,
    'INITIALIZE',
    message,
    'HLAS-PMS',
    userEmail,
    result || '성공',
  ]);

  sheet.getRange(sheet.getLastRow(), 3).setNumberFormat('yyyy-mm-dd hh:mm:ss');
}

