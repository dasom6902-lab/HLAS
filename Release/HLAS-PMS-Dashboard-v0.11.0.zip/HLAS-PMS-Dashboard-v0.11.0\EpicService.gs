/**
 * EPIC 생성 화면에서 사용할 프로젝트 선택 목록을 반환한다.
 *
 * @return {Object[]} PROJECT_ID와 프로젝트명 목록
 */
function getProjectOptions() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = spreadsheet.getSheetByName('01_PROJECT');

  if (!sheet || sheet.getLastRow() < 2) {
    return [];
  }

  return sheet
    .getRange(2, 1, sheet.getLastRow() - 1, 2)
    .getDisplayValues()
    .filter(function (row) {
      return String(row[0] || '').trim() !== '';
    })
    .map(function (row) {
      return {
        projectId: String(row[0]).trim(),
        projectName: String(row[1]).trim(),
      };
    });
}

/**
 * EPIC 입력값을 검증하고 02_EPIC 시트에 저장한다.
 *
 * @param {Object} formData EPIC 입력 데이터
 * @return {Object} 저장 결과
 */
function createEpicRecord(formData) {
  const data = formData || {};

  // Validation.gs 도입 전까지 사용하는 임시 직접 검증 영역이다.
  const projectId = String(data.projectId || '').trim();
  const epicName = String(data.epicName || '').trim();

  if (!projectId) {
    throw new Error('프로젝트를 선택해 주세요.');
  }
  if (!epicName) {
    throw new Error('EPIC명을 입력해 주세요.');
  }

  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const projectSheet = spreadsheet.getSheetByName('01_PROJECT');
  const epicSheet = spreadsheet.getSheetByName('02_EPIC');

  if (!projectSheet || !epicSheet) {
    throw new Error('필수 시트가 없습니다. PMS 초기화를 먼저 실행해 주세요.');
  }

  // 저장 시점에도 PROJECT_ID가 실제로 존재하는지 다시 검증한다.
  if (!epicProjectExists_(projectSheet, projectId)) {
    throw new Error('선택한 프로젝트를 찾을 수 없습니다.');
  }

  // 임시 ID 생성과 저장을 한 잠금 영역에서 처리하여 중복을 방지한다.
  const lock = LockService.getDocumentLock();
  lock.waitLock(30000);

  try {
    const epicId = generateNextEpicId_(epicSheet);
    const now = new Date();
    const startDate = parseEpicDate_(data.startDate);
    const plannedEndDate = parseEpicDate_(data.plannedEndDate);

    if (
      startDate instanceof Date &&
      plannedEndDate instanceof Date &&
      plannedEndDate.getTime() < startDate.getTime()
    ) {
      throw new Error('종료예정일은 시작일보다 빠를 수 없습니다.');
    }

    const row = [
      epicId,
      projectId,
      epicName,
      String(data.description || '').trim(),
      '진행중',
      String(data.priority || '보통').trim(),
      String(data.owner || '').trim(),
      startDate,
      plannedEndDate,
      now,
      now,
    ];

    epicSheet.appendRow(row);

    const savedRow = epicSheet.getLastRow();
    epicSheet.getRange(savedRow, 8, 1, 2).setNumberFormat('yyyy-mm-dd');
    epicSheet.getRange(savedRow, 10, 1, 2).setNumberFormat('yyyy-mm-dd hh:mm:ss');

    // LogService.gs 도입 전까지 기존 CHANGELOG 기록 함수를 직접 호출한다.
    appendChangeLog_(
      spreadsheet,
      'EPIC 생성: ' + epicName,
      now,
      '성공',
      'EPIC 생성',
      epicId
    );

    SpreadsheetApp.flush();

    return {
      success: true,
      epicId: epicId,
      message: 'EPIC이 생성되었습니다.',
    };
  } finally {
    lock.releaseLock();
  }
}

/**
 * 등록된 EPIC 목록을 프로젝트명과 함께 반환한다.
 *
 * @return {Object[]} EPIC 목록
 */
function getEpicList(options) {
  const response = search(HLAS_CONSTANTS.ENTITY.EPIC, options);
  if (!response.ok) {
    throw coreErrorFromResponse_(response.error);
  }

  const projectMap = {};
  getProjectOptions().forEach(function (project) {
    projectMap[project.projectId] = project.projectName;
  });

  return response.data.map(function (record) {
      return {
        epicId: record.EPIC_ID,
        projectId: record.PROJECT_ID,
        projectName: projectMap[record.PROJECT_ID] || '',
        epicName: record['EPIC명'],
        description: record['설명'],
        status: record['상태'],
        priority: record['우선순위'],
        owner: record['담당자'],
        startDate: record['시작일'],
        plannedEndDate: record['종료예정일'],
        createdAt: record['생성일시'],
        updatedAt: record['수정일시'],
      };
    });
}

/**
 * EPIC을 삭제한다. 하위 FEATURE가 있으면 삭제하지 않는다.
 *
 * @param {string} id 삭제할 EPIC_ID
 * @return {Object} Core API 표준 응답
 */
function deleteEpic(id) {
  return CommonAPI.execute(function () {
    Validation.required(id, HLAS_CONSTANTS.EPIC_FIELD.EPIC_ID);
    const normalizedId = String(id).trim();
    const current = SheetRepository.findById(
      HLAS_CONSTANTS.SHEETS.EPIC,
      normalizedId
    );

    if (!current) {
      throw new NotFoundError(
        '삭제할 EPIC을 찾을 수 없습니다: ' + normalizedId,
        HLAS_CONSTANTS.EPIC_FIELD.EPIC_ID,
        { id: normalizedId }
      );
    }

    assertDeleteAllowed_(
      canDeleteEpic(normalizedId),
      HLAS_CONSTANTS.EPIC_FIELD.EPIC_ID,
      normalizedId
    );
    SheetRepository.delete(HLAS_CONSTANTS.SHEETS.EPIC, normalizedId);

    CommonAPI.writeLog({
      changeType: HLAS_CONSTANTS.LOG_TYPE.EPIC_DELETE,
      message:
        'EPIC 삭제: ' + current[HLAS_CONSTANTS.EPIC_FIELD.EPIC_NAME],
      relatedId: normalizedId,
      result: HLAS_CONSTANTS.LOG_RESULT.SUCCESS,
    });

    return { epicId: normalizedId, deleted: true };
  }, { operation: 'deleteEpic' });
}

/**
 * PROJECT_ID의 존재 여부를 확인한다.
 *
 * @param {GoogleAppsScript.Spreadsheet.Sheet} sheet 프로젝트 시트
 * @param {string} projectId 확인할 PROJECT_ID
 * @return {boolean} 존재 여부
 */
function epicProjectExists_(sheet, projectId) {
  if (sheet.getLastRow() < 2) {
    return false;
  }

  const ids = sheet
    .getRange(2, 1, sheet.getLastRow() - 1, 1)
    .getDisplayValues();

  return ids.some(function (row) {
    return String(row[0] || '').trim() === projectId;
  });
}

/**
 * 현재 EPIC_ID 중 가장 큰 번호 다음 값을 발급한다.
 *
 * 공통 IdGenerator 승인 전까지 사용하는 임시 구현이다.
 *
 * @param {GoogleAppsScript.Spreadsheet.Sheet} sheet EPIC 시트
 * @return {string} 새 EPIC_ID
 */
function generateNextEpicId_(sheet) {
  const lastRow = sheet.getLastRow();
  let maxNumber = 0;

  if (lastRow > 1) {
    const ids = sheet.getRange(2, 1, lastRow - 1, 1).getDisplayValues();

    ids.forEach(function (row) {
      const match = String(row[0] || '').trim().match(/^EPIC-(\d{4,})$/);
      if (match) {
        maxNumber = Math.max(maxNumber, Number(match[1]));
      }
    });
  }

  return 'EPIC-' + String(maxNumber + 1).padStart(4, '0');
}

/**
 * HTML date 값을 스프레드시트 날짜로 변환한다.
 *
 * Validation.gs 승인 전까지 사용하는 임시 구현이다.
 *
 * @param {string} value yyyy-mm-dd 형식
 * @return {Date|string} 날짜 또는 빈 값
 */
function parseEpicDate_(value) {
  const text = String(value || '').trim();
  if (!text) {
    return '';
  }

  const parts = text.split('-').map(Number);
  if (parts.length !== 3 || !parts[0] || !parts[1] || !parts[2]) {
    throw new Error('날짜 형식이 올바르지 않습니다.');
  }

  const date = new Date(parts[0], parts[1] - 1, parts[2]);

  if (
    date.getFullYear() !== parts[0] ||
    date.getMonth() !== parts[1] - 1 ||
    date.getDate() !== parts[2]
  ) {
    throw new Error('유효하지 않은 날짜입니다.');
  }

  return date;
}
