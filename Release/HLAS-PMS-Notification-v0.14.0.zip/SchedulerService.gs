/**
 * 24시간 이내 마감 예정인 미완료 TASK를 점검한다.
 *
 * @return {Object} Core API 표준 응답
 */
function checkDueTasks() {
  return checkTaskSchedule_('DUE');
}

/**
 * 완료예정일이 지난 미완료 TASK를 점검한다.
 *
 * @return {Object} Core API 표준 응답
 */
function checkOverdueTasks() {
  return checkTaskSchedule_('OVERDUE');
}

/**
 * 승인 대기 업무 점검을 위한 확장 지점을 제공한다.
 *
 * 현재 승인 상태 컬럼이 없으므로 실제 생성 없이 점검 결과만 반환한다.
 *
 * @return {Object} Core API 표준 응답
 */
function checkPendingApproval() {
  return CommonAPI.success(
    { checked: true, createdCount: 0, reason: '승인 상태 모델 도입 전' },
    { operation: 'checkPendingApproval' }
  );
}

/**
 * 일 단위 스케줄 작업을 실행한다.
 *
 * @return {Object} Core API 표준 응답
 */
function runDailyJobs() {
  return CommonAPI.execute(function () {
    try {
      const due = unwrapSchedulerResponse_(checkDueTasks());
      const overdue = unwrapSchedulerResponse_(checkOverdueTasks());
      const result = { due: due, overdue: overdue };
      writeSchedulerAudit_('runDailyJobs', result, null);
      return result;
    } catch (error) {
      writeSchedulerAudit_('runDailyJobs', null, error);
      throw error;
    }
  }, { operation: 'runDailyJobs' });
}

/**
 * 시간 단위 스케줄 작업을 실행한다.
 *
 * @return {Object} Core API 표준 응답
 */
function runHourlyJobs() {
  return CommonAPI.execute(function () {
    try {
      const pending = unwrapSchedulerResponse_(checkPendingApproval());
      const result = { pendingApproval: pending };
      writeSchedulerAudit_('runHourlyJobs', result, null);
      return result;
    } catch (error) {
      writeSchedulerAudit_('runHourlyJobs', null, error);
      throw error;
    }
  }, { operation: 'runHourlyJobs' });
}

/**
 * 시간·일 단위 Apps Script 트리거를 중복 없이 등록한다.
 *
 * 실제 운영 적용 시 사용자가 이 함수를 별도로 실행한다.
 *
 * @return {Object} Core API 표준 응답
 */
function registerSchedulerTriggers() {
  return CommonAPI.execute(function () {
    assertPermission_(
      HLAS_CONSTANTS.PERMISSION.CREATE,
      HLAS_CONSTANTS.ENTITY.NOTIFICATION,
      'SCHEDULER'
    );
    removeSchedulerTriggers_();
    ScriptApp.newTrigger('runHourlyJobs').timeBased().everyHours(1).create();
    ScriptApp.newTrigger('runDailyJobs')
      .timeBased().everyDays(1).atHour(8).create();
    return { registered: true, handlers: ['runHourlyJobs', 'runDailyJobs'] };
  }, { operation: 'registerSchedulerTriggers' });
}

/**
 * HLAS 스케줄러 트리거를 제거한다.
 *
 * @return {Object} Core API 표준 응답
 */
function removeSchedulerTriggers() {
  return CommonAPI.execute(function () {
    assertPermission_(
      HLAS_CONSTANTS.PERMISSION.DELETE,
      HLAS_CONSTANTS.ENTITY.NOTIFICATION,
      'SCHEDULER'
    );
    return { removedCount: removeSchedulerTriggers_() };
  }, { operation: 'removeSchedulerTriggers' });
}

function checkTaskSchedule_(mode) {
  return CommonAPI.execute(function () {
    const C = HLAS_CONSTANTS;
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrow = new Date(today.getTime() + 24 * 60 * 60 * 1000);
    let createdCount = 0;
    const title = mode === 'DUE' ? 'TASK 마감 임박' : 'TASK 기한 초과';
    const type = mode === 'DUE'
      ? C.NOTIFICATION_TYPE.WARNING
      : C.NOTIFICATION_TYPE.ERROR;

    const existingNotifications =
      SheetRepository.findAll(C.SHEETS.NOTIFICATION);
    const notificationKeys = {};
    existingNotifications.forEach(function (notification) {
      const key =
        String(notification[C.NOTIFICATION_FIELD.ENTITY_ID] || '') +
        '|' +
        String(notification[C.NOTIFICATION_FIELD.TITLE] || '');
      notificationKeys[key] = true;
    });

    SheetRepository.findAll(C.SHEETS.TASK).forEach(function (task) {
      const fields = C.TASK_FIELD;
      const status = String(task[fields.STATUS] || '');
      if (
        status === C.STATUS.COMPLETED ||
        status === C.STATUS.CANCELLED
      ) return;
      const due = new Date(task[fields.PLANNED_END_DATE]);
      if (isNaN(due.getTime())) return;
      const normalizedDue =
        new Date(due.getFullYear(), due.getMonth(), due.getDate());
      const matches = mode === 'DUE'
        ? normalizedDue >= today && normalizedDue <= tomorrow
        : normalizedDue < today;
      const taskId = String(task[fields.TASK_ID] || '');
      const notificationKey = taskId + '|' + title;
      if (!matches || notificationKeys[notificationKey]) return;

      const response = createNotification({
        type: type,
        user: String(task[fields.OWNER] || ''),
        entity: C.ENTITY.TASK,
        entityId: taskId,
        title: title,
        message: String(task[fields.TASK_NAME] || '') +
          (mode === 'DUE' ? '의 마감일이 임박했습니다.' : '의 기한이 초과되었습니다.'),
      });
      if (!response.ok) {
        throw new CoreError(
          response.error.code,
          response.error.message,
          response.error.field,
          response.error.details
        );
      }
      notificationKeys[notificationKey] = true;
      createdCount += 1;
    });
    return { checked: true, createdCount: createdCount };
  }, { operation: mode === 'DUE' ? 'checkDueTasks' : 'checkOverdueTasks' });
}

function notifyTaskCompletion_(taskRecord, previousStatus) {
  const C = HLAS_CONSTANTS;
  const fields = C.TASK_FIELD;
  if (
    previousStatus === C.STATUS.COMPLETED ||
    taskRecord[fields.STATUS] !== C.STATUS.COMPLETED
  ) return null;
  const taskId = String(taskRecord[fields.TASK_ID] || '');
  const title = 'TASK 완료';
  if (notificationExists_(taskId, title)) return null;
  return createNotification({
    type: C.NOTIFICATION_TYPE.SUCCESS,
    user: String(taskRecord[fields.OWNER] || ''),
    entity: C.ENTITY.TASK,
    entityId: taskId,
    title: title,
    message: String(taskRecord[fields.TASK_NAME] || '') + '이 완료되었습니다.',
  });
}

function writeSchedulerAudit_(jobName, detail, error) {
  const C = HLAS_CONSTANTS;
  return writeEntityAudit_(
    C.AUDIT_ACTION.SCHEDULER,
    C.ENTITY.NOTIFICATION,
    jobName,
    error ? C.AUDIT_RESULT.FAIL : C.AUDIT_RESULT.SUCCESS,
    error ? 'Scheduler 실행 실패' : 'Scheduler 실행 완료',
    error ? { error: error.message } : detail
  );
}

function unwrapSchedulerResponse_(response) {
  if (response && response.ok) return response.data;
  const error = response && response.error ? response.error : {};
  throw new CoreError(
    error.code || 'SCHEDULER_ERROR',
    error.message || 'Scheduler 실행 중 오류가 발생했습니다.',
    error.field || null,
    error.details || null
  );
}

function removeSchedulerTriggers_() {
  const handlers = ['runHourlyJobs', 'runDailyJobs'];
  let count = 0;
  ScriptApp.getProjectTriggers().forEach(function (trigger) {
    if (handlers.indexOf(trigger.getHandlerFunction()) !== -1) {
      ScriptApp.deleteTrigger(trigger);
      count += 1;
    }
  });
  return count;
}
